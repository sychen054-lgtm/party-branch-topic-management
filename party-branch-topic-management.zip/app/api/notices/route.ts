import { createClient } from "@/lib/supabase/server";
import { NextResponse } from "next/server";

export async function GET() {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("notices")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  const notices = (data || []).map((row: Record<string, unknown>) => ({
    id: row.id,
    title: row.title,
    content: row.content,
    type: row.type,
    isRead: row.is_read,
    createdAt: row.created_at,
  }));

  return NextResponse.json(notices);
}
