import { createClient } from "@/lib/supabase/server";
import { NextResponse } from "next/server";

export async function GET() {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("branch_elections")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  const elections = (data || []).map((row: Record<string, unknown>) => ({
    id: row.id,
    branchName: row.branch_name,
    termEndDate: row.term_end_date,
    currentStage: row.current_stage,
    currentStageIndex: row.current_stage_index,
    currentNode: row.current_node,
    progress: row.progress,
    status: row.status,
    lastUpdateDate: row.last_update_date,
  }));

  return NextResponse.json(elections);
}
