import { createClient } from "@/lib/supabase/server";
import { NextResponse } from "next/server";

export async function GET(request: Request) {
  const supabase = await createClient();
  const { searchParams } = new URL(request.url);
  const status = searchParams.get("status");

  let query = supabase.from("projects").select("*").order("created_at", { ascending: false });

  if (status) {
    if (status === "concluded") {
      query = query.eq("status", "concluded");
    } else if (status === "active") {
      query = query.neq("status", "concluded");
    } else {
      query = query.eq("status", status);
    }
  }

  const { data, error } = await query;

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  // Transform DB rows to match frontend types
  const projects = (data || []).map((row: Record<string, unknown>) => ({
    id: row.id,
    title: row.title,
    description: row.description,
    category: row.category,
    organizationId: row.organization_id,
    organizationName: row.organization_name,
    leader: row.leader,
    members: row.members || [],
    objectives: row.objectives,
    measures: row.measures,
    plan: row.plan,
    expectedOutcomes: row.expected_outcomes,
    status: row.status,
    progress: row.progress,
    conclusionReport: row.conclusion_report,
    citySelection: row.city_selection,
    provinceSelection: row.province_selection,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  }));

  return NextResponse.json(projects);
}

export async function POST(request: Request) {
  const supabase = await createClient();
  const body = await request.json();

  const { data, error } = await supabase.from("projects").insert({
    id: body.id || `proj-${Date.now()}`,
    title: body.title,
    description: body.description,
    category: body.category,
    organization_id: body.organizationId,
    organization_name: body.organizationName,
    leader: body.leader,
    members: body.members || [],
    objectives: body.objectives,
    measures: body.measures,
    plan: body.plan,
    expected_outcomes: body.expectedOutcomes,
    status: body.status || "draft",
    progress: body.progress || 0,
  }).select().single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json(data);
}
