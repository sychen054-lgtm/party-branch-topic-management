"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { useProjects } from "@/lib/hooks/use-data";
import {
  Search,
  ChevronDown,
  ChevronRight,
  Building2,
  Trophy,
  Award,
  Eye,
  Send,
} from "lucide-react";

// 市局评选状态
type CitySelectionStatus = "pending" | "awarded" | "not_awarded";
// 省局评选状态
type ProvinceSelectionStatus = "not_recommended" | "pending" | "awarded" | "not_awarded";

const cityStatusConfig: Record<CitySelectionStatus, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
  pending: { label: "评选中", variant: "secondary" },
  awarded: { label: "获奖", variant: "default" },
  not_awarded: { label: "未获奖", variant: "outline" },
};

const provinceStatusConfig: Record<ProvinceSelectionStatus, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
  not_recommended: { label: "未推荐", variant: "outline" },
  pending: { label: "评选中", variant: "secondary" },
  awarded: { label: "获奖", variant: "default" },
  not_awarded: { label: "未获奖", variant: "outline" },
};

// recommendedProjects is computed inside the component after SWR data loads

// 年份列表
const years = Array.from({ length: 5 }, (_, i) => (new Date().getFullYear() - i).toString());

// 组织树结构
interface OrgNode {
  id: string;
  name: string;
  children?: OrgNode[];
}

const orgTree: OrgNode[] = [
  {
    id: "org-1",
    name: "机关党委",
    children: [
      { id: "org-1-1", name: "第一党支部" },
      { id: "org-1-2", name: "第二党支部" },
      { id: "org-1-3", name: "第三党支部" },
    ],
  },
  {
    id: "org-2",
    name: "直属机关党委",
    children: [
      { id: "org-2-1", name: "综合党支部" },
      { id: "org-2-2", name: "业务党支部" },
    ],
  },
];

export function SelectionManagement() {
  const { data: projects = [] } = useProjects("concluded");

  const recommendedProjects = projects
    .filter((p: Record<string, unknown>) => p.status === "approved" || p.status === "in_progress" || p.status === "concluded")
    .slice(0, 8)
    .map((p: Record<string, unknown>, index: number) => ({
      ...p,
      cityStatus: (
        index < 6 ? "awarded" : "pending"
      ) as CitySelectionStatus,
      cityAward: index === 0 ? "一等奖" : index === 1 ? "二等奖" : index < 6 ? "三等奖" : undefined,
      provinceStatus: (
        index === 0 ? "awarded" :
        index === 1 ? "pending" :
        index === 2 ? "not_awarded" :
        "not_recommended"
      ) as ProvinceSelectionStatus,
      provinceAward: index === 0 ? "二等奖" : undefined,
      recommendedAt: new Date(2024, 5, 10 + index).toISOString(),
    }));

  const [searchTerm, setSearchTerm] = useState("");
  const [yearFilter, setYearFilter] = useState<string>("all");
  const [cityStatusFilter, setCityStatusFilter] = useState<string>("all");
  const [provinceStatusFilter, setProvinceStatusFilter] = useState<string>("all");
  const [selectedOrg, setSelectedOrg] = useState<string>("all");
  const [expandedOrgs, setExpandedOrgs] = useState<string[]>(["org-1", "org-2"]);
  const [orgPopoverOpen, setOrgPopoverOpen] = useState(false);

  const [viewingProject, setViewingProject] = useState<typeof recommendedProjects[0] | null>(null);
  const [recommendingProject, setRecommendingProject] = useState<typeof recommendedProjects[0] | null>(null);

  // 获取组织及其子组织的所有ID
  const getOrgAndChildrenIds = (orgId: string): string[] => {
    const ids: string[] = [orgId];
    const findChildren = (nodes: OrgNode[]) => {
      for (const node of nodes) {
        if (node.id === orgId && node.children) {
          node.children.forEach((child) => ids.push(child.id));
        }
        if (node.children) {
          findChildren(node.children);
        }
      }
    };
    findChildren(orgTree);
    return ids;
  };

  // 获取选中组织的名称
  const getSelectedOrgName = () => {
    if (selectedOrg === "all") return "全部党支部";
    const findName = (nodes: OrgNode[]): string | null => {
      for (const node of nodes) {
        if (node.id === selectedOrg) return node.name;
        if (node.children) {
          const found = findName(node.children);
          if (found) return found;
        }
      }
      return null;
    };
    return findName(orgTree) || "全部党支部";
  };

  // 切换组织展开/收起
  const toggleOrgExpand = (orgId: string) => {
    setExpandedOrgs((prev) =>
      prev.includes(orgId) ? prev.filter((id) => id !== orgId) : [...prev, orgId]
    );
  };

  // 渲染组织树
  const renderOrgTree = (nodes: OrgNode[], level = 0) => {
    return nodes.map((node) => (
      <div key={node.id}>
        <div
          className={`flex items-center gap-2 py-1.5 px-2 rounded cursor-pointer hover:bg-muted ${
            selectedOrg === node.id ? "bg-primary/10 text-primary" : ""
          }`}
          style={{ paddingLeft: `${level * 16 + 8}px` }}
          onClick={() => {
            if (node.children) {
              toggleOrgExpand(node.id);
            }
            setSelectedOrg(node.id);
            if (!node.children) {
              setOrgPopoverOpen(false);
            }
          }}
        >
          {node.children ? (
            expandedOrgs.includes(node.id) ? (
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            ) : (
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            )
          ) : (
            <div className="w-4" />
          )}
          <Building2 className="h-4 w-4 text-muted-foreground" />
          <span className="text-sm">{node.name}</span>
        </div>
        {node.children && expandedOrgs.includes(node.id) && renderOrgTree(node.children, level + 1)}
      </div>
    ));
  };

  // 筛选课题
  const filteredProjects = recommendedProjects.filter((project) => {
    const matchesSearch =
      project.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      project.organizationName.toLowerCase().includes(searchTerm.toLowerCase());

    const projectYear = new Date(project.recommendedAt).getFullYear().toString();
    const matchesYear = yearFilter === "all" || projectYear === yearFilter;

    const matchesCityStatus = cityStatusFilter === "all" || project.cityStatus === cityStatusFilter;
    const matchesProvinceStatus = provinceStatusFilter === "all" || project.provinceStatus === provinceStatusFilter;

    let matchesOrg = true;
    if (selectedOrg !== "all") {
      const orgIds = getOrgAndChildrenIds(selectedOrg);
      matchesOrg = orgIds.includes(project.organizationId);
    }

    return matchesSearch && matchesYear && matchesCityStatus && matchesProvinceStatus && matchesOrg;
  });

  // 推荐至省局
  const handleRecommendToProvince = () => {
    alert(`已将课题"${recommendingProject?.title}"推荐至省局评选`);
    setRecommendingProject(null);
  };

  // 统计数据
  const stats = {
    total: recommendedProjects.length,
    cityAwarded: recommendedProjects.filter((p) => p.cityStatus === "awarded").length,
    provinceRecommended: recommendedProjects.filter((p) => p.provinceStatus !== "not_recommended").length,
    provinceAwarded: recommendedProjects.filter((p) => p.provinceStatus === "awarded").length,
  };

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-4">
        <Card>
          <CardContent className="flex items-center gap-4 p-4">
            <div className="rounded-lg bg-primary/10 p-3">
              <Trophy className="h-5 w-5 text-primary" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{stats.total}</p>
              <p className="text-sm text-muted-foreground">推荐课题总数</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-4 p-4">
            <div className="rounded-lg bg-emerald-100 p-3">
              <Award className="h-5 w-5 text-emerald-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{stats.cityAwarded}</p>
              <p className="text-sm text-muted-foreground">市局获奖</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-4 p-4">
            <div className="rounded-lg bg-amber-100 p-3">
              <Send className="h-5 w-5 text-amber-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{stats.provinceRecommended}</p>
              <p className="text-sm text-muted-foreground">推荐省局</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="flex items-center gap-4 p-4">
            <div className="rounded-lg bg-rose-100 p-3">
              <Award className="h-5 w-5 text-rose-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{stats.provinceAwarded}</p>
              <p className="text-sm text-muted-foreground">省局获奖</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-wrap items-center gap-4">
            {/* Search */}
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="搜索课题名称或党支部..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>

            {/* Year Filter */}
            <Select value={yearFilter} onValueChange={setYearFilter}>
              <SelectTrigger className="w-28">
                <SelectValue placeholder="年份" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部年份</SelectItem>
                {years.map((year) => (
                  <SelectItem key={year} value={year}>
                    {year}年
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Organization Tree */}
            <Popover open={orgPopoverOpen} onOpenChange={setOrgPopoverOpen}>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-40 justify-between bg-transparent">
                  <span className="truncate">{getSelectedOrgName()}</span>
                  <ChevronDown className="h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-64 p-2" align="start">
                <div
                  className={`flex items-center gap-2 py-1.5 px-2 rounded cursor-pointer hover:bg-muted ${
                    selectedOrg === "all" ? "bg-primary/10 text-primary" : ""
                  }`}
                  onClick={() => {
                    setSelectedOrg("all");
                    setOrgPopoverOpen(false);
                  }}
                >
                  <div className="w-4" />
                  <Building2 className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">全部党支部</span>
                </div>
                {renderOrgTree(orgTree)}
              </PopoverContent>
            </Popover>

            {/* City Status Filter */}
            <Select value={cityStatusFilter} onValueChange={setCityStatusFilter}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="市局评选" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">市局-全部</SelectItem>
                <SelectItem value="pending">市局-评选中</SelectItem>
                <SelectItem value="awarded">市局-获奖</SelectItem>
                <SelectItem value="not_awarded">市局-未获奖</SelectItem>
              </SelectContent>
            </Select>

            {/* Province Status Filter */}
            <Select value={provinceStatusFilter} onValueChange={setProvinceStatusFilter}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="省局评选" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">省局-全部</SelectItem>
                <SelectItem value="not_recommended">省局-未推荐</SelectItem>
                <SelectItem value="pending">省局-评选中</SelectItem>
                <SelectItem value="awarded">省局-获奖</SelectItem>
                <SelectItem value="not_awarded">省局-未获奖</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Project List Table */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">评选课题列表</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12">序号</TableHead>
                <TableHead className="w-20">年份</TableHead>
                <TableHead className="w-28">党支部</TableHead>
                <TableHead>课题名称</TableHead>
                <TableHead className="w-32">市局评选</TableHead>
                <TableHead className="w-32">省局评选</TableHead>
                <TableHead className="w-28">推荐时间</TableHead>
                <TableHead className="text-right w-36">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredProjects.map((project, index) => {
                const cityConfig = cityStatusConfig[project.cityStatus];
                const provinceConfig = provinceStatusConfig[project.provinceStatus];
                const canRecommendToProvince = project.cityStatus === "awarded" && project.provinceStatus === "not_recommended";
                
                return (
                  <TableRow key={project.id}>
                    <TableCell className="text-center text-muted-foreground">{index + 1}</TableCell>
                    <TableCell>
                      {new Date(project.recommendedAt).getFullYear()}
                    </TableCell>
                    <TableCell>{project.organizationName}</TableCell>
                    <TableCell className="font-medium">
                      <span className="line-clamp-1">{project.title}</span>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col gap-1">
                        <Badge variant={cityConfig.variant}>
                          {cityConfig.label}
                        </Badge>
                        {project.cityAward && (
                          <span className="text-xs text-primary">{project.cityAward}</span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col gap-1">
                        <Badge variant={provinceConfig.variant}>
                          {provinceConfig.label}
                        </Badge>
                        {project.provinceAward && (
                          <span className="text-xs text-primary">{project.provinceAward}</span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      {new Date(project.recommendedAt).toLocaleDateString("zh-CN")}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setViewingProject(project)}
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          详情
                        </Button>
                        {canRecommendToProvince && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setRecommendingProject(project)}
                          >
                            <Send className="h-4 w-4 mr-1" />
                            推荐省局
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
              {filteredProjects.length === 0 && (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-12 text-muted-foreground">
                    没有找到符合条件的评选课题
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* View Detail Dialog */}
      <Dialog open={!!viewingProject} onOpenChange={() => setViewingProject(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>课题详情</DialogTitle>
          </DialogHeader>
          {viewingProject && (
            <div className="space-y-4 py-4">
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">课题名称</p>
                <p className="font-medium">{viewingProject.title}</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">党支部</p>
                  <p className="font-medium">{viewingProject.organizationName}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">负责人</p>
                  <p className="font-medium">{viewingProject.leader}</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">市局评选</p>
                  <div className="flex items-center gap-2">
                    <Badge variant={cityStatusConfig[viewingProject.cityStatus].variant}>
                      {cityStatusConfig[viewingProject.cityStatus].label}
                    </Badge>
                    {viewingProject.cityAward && (
                      <span className="text-sm text-primary">{viewingProject.cityAward}</span>
                    )}
                  </div>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">省局评选</p>
                  <div className="flex items-center gap-2">
                    <Badge variant={provinceStatusConfig[viewingProject.provinceStatus].variant}>
                      {provinceStatusConfig[viewingProject.provinceStatus].label}
                    </Badge>
                    {viewingProject.provinceAward && (
                      <span className="text-sm text-primary">{viewingProject.provinceAward}</span>
                    )}
                  </div>
                </div>
              </div>
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">课题简介</p>
                <p className="text-sm bg-muted/30 rounded-lg p-3">{viewingProject.description}</p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Recommend to Province Dialog */}
      <Dialog open={!!recommendingProject} onOpenChange={() => setRecommendingProject(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>推荐至省局评选</DialogTitle>
          </DialogHeader>
          {recommendingProject && (
            <div className="space-y-4 py-4">
              <div className="rounded-lg bg-muted/50 p-4">
                <p className="text-sm text-muted-foreground mb-1">课题名称</p>
                <p className="font-medium">{recommendingProject.title}</p>
              </div>
              <div className="rounded-lg bg-muted/50 p-4">
                <p className="text-sm text-muted-foreground mb-1">市局获奖情况</p>
                <p className="font-medium text-primary">{recommendingProject.cityAward}</p>
              </div>
              <div className="rounded-lg border border-primary/20 bg-primary/5 p-4">
                <p className="text-sm font-medium text-primary mb-2">确认推荐至省局评选</p>
                <p className="text-sm text-muted-foreground">
                  该课题已获得市局{recommendingProject.cityAward}，确认后将被推荐参加省局评选。
                </p>
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <Button
                  variant="outline"
                  onClick={() => setRecommendingProject(null)}
                  className="bg-transparent"
                >
                  取消
                </Button>
                <Button className="gap-2" onClick={handleRecommendToProvince}>
                  <Send className="h-4 w-4" />
                  确认推荐
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
