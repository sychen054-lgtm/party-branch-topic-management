"use client";

import React from "react"

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { cn } from "@/lib/utils";
import {
  LayoutDashboard,
  Bell,
  FileText,
  Trophy,
  BookOpen,
  FolderKanban,
  LogOut,
  ChevronDown,
  ChevronRight,
  GitBranch,
  Users,
  RefreshCw,
} from "lucide-react";

interface NavItem {
  name: string;
  href?: string;
  icon: React.ElementType;
  children?: NavItem[];
}

const navigation: NavItem[] = [
  { name: "工作台", href: "/", icon: LayoutDashboard },
  {
    name: "书记课题",
    icon: FileText,
    children: [
      { name: "通知公告", href: "/notices", icon: Bell },
      { name: "课题申报", href: "/projects/apply", icon: FileText },
      { name: "课题管理", href: "/projects", icon: FolderKanban },
      { name: "评选管理", href: "/selection", icon: Trophy },
      { name: "案例集", href: "/cases", icon: BookOpen },
    ],
  },
  {
    name: "党员发展",
    icon: Users,
    children: [
      { name: "流程模板", href: "/member-development/template", icon: GitBranch },
      { name: "流程详情", href: "/member-development/list", icon: FolderKanban },
    ],
  },
  {
    name: "支部换届",
    icon: RefreshCw,
    children: [
      { name: "流程模板", href: "/branch-election/template", icon: GitBranch },
      { name: "流程详情", href: "/branch-election/list", icon: FolderKanban },
    ],
  },
];

export function AppSidebar() {
  const pathname = usePathname();
  const [expandedMenus, setExpandedMenus] = useState<string[]>(["书记课题", "党员发展", "支部换届"]);

  const toggleMenu = (name: string) => {
    setExpandedMenus((prev) =>
      prev.includes(name) ? prev.filter((n) => n !== name) : [...prev, name]
    );
  };

  const isActive = (href: string) => {
    if (href === "/") return pathname === "/";
    if (href === "/projects") {
      return pathname.startsWith("/projects") && !pathname.startsWith("/projects/apply");
    }
    return pathname.startsWith(href);
  };

  const isParentActive = (children: NavItem[]) => {
    return children.some((child) => child.href && isActive(child.href));
  };

  return (
    <aside className="flex h-screen w-60 flex-col bg-sidebar">
      {/* Logo */}
      <div className="flex h-16 items-center gap-3 px-5">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-sidebar-primary">
          <FileText className="h-4 w-4 text-sidebar-primary-foreground" />
        </div>
        <span className="text-sm font-semibold text-sidebar-foreground">
          党建课题管理平台
        </span>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-4 overflow-y-auto sidebar-scrollbar">
        <ul className="space-y-1">
          {navigation.map((item) => {
            if (item.children) {
              const isExpanded = expandedMenus.includes(item.name);
              const hasActiveChild = isParentActive(item.children);

              return (
                <li key={item.name}>
                  <button
                    onClick={() => toggleMenu(item.name)}
                    className={cn(
                      "flex w-full items-center justify-between gap-3 rounded-lg px-3 py-2.5 text-sm transition-all duration-200",
                      hasActiveChild
                        ? "text-sidebar-foreground font-medium"
                        : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-foreground"
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <item.icon className="h-[18px] w-[18px]" />
                      {item.name}
                    </div>
                    {isExpanded ? (
                      <ChevronDown className="h-4 w-4" />
                    ) : (
                      <ChevronRight className="h-4 w-4" />
                    )}
                  </button>
                  {isExpanded && (
                    <ul className="mt-1 ml-4 space-y-1 border-l border-sidebar-border pl-3">
                      {item.children.map((child) => {
                        const childActive = child.href ? isActive(child.href) : false;
                        return (
                          <li key={child.name}>
                            <Link
                              href={child.href || "#"}
                              className={cn(
                                "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-all duration-200",
                                childActive
                                  ? "bg-sidebar-primary text-sidebar-primary-foreground font-medium"
                                  : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"
                              )}
                            >
                              <child.icon className="h-4 w-4" />
                              {child.name}
                            </Link>
                          </li>
                        );
                      })}
                    </ul>
                  )}
                </li>
              );
            }

            const itemActive = item.href ? isActive(item.href) : false;
            return (
              <li key={item.name}>
                <Link
                  href={item.href || "#"}
                  className={cn(
                    "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition-all duration-200",
                    itemActive
                      ? "bg-sidebar-primary text-sidebar-primary-foreground font-medium"
                      : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-foreground"
                  )}
                >
                  <item.icon className="h-[18px] w-[18px]" />
                  {item.name}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* User */}
      <div className="p-3">
        <div className="flex items-center gap-3 rounded-lg bg-sidebar-accent/60 px-3 py-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-sidebar-primary text-xs font-medium text-sidebar-primary-foreground">
            管
          </div>
          <div className="flex-1 min-w-0">
            <p className="truncate text-sm font-medium text-sidebar-foreground">管理员</p>
            <p className="truncate text-xs text-sidebar-foreground/60">党建工作处</p>
          </div>
          <button className="p-1.5 rounded-md hover:bg-sidebar-border/50 transition-colors">
            <LogOut className="h-4 w-4 text-sidebar-foreground/60" />
          </button>
        </div>
      </div>
    </aside>
  );
}
